package com.ibm.iic;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import javax.annotation.Resource;

// @author
// @version 0.1

/**
 * Servlet implementation class SQLDBLibertySample
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Resource(lookup = "jdbc/mySQLDB")
	DataSource ds;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		response.setStatus(200);
		// System.out.println("IBM SQL Database, Java Demo Application using WebSphere Liberty Profile Resources");
		// System.out.println("Servlet: " + this.getClass().getName());
		Statement stmt = null;
		Connection con = null;
		try {
			con = ds.getConnection();
			con.setAutoCommit(false);
		} catch (SQLException e) {
			// System.out.println("Error: " + e);
		}

		String tableName = "";
		String sqlStatement = "";
		String schemaName = "SQLDBSAMPLE";
		// create a unique table name to make sure we deal with our own table
		tableName = schemaName + "." + "ENROLL";

		// Remove the table from the database
		try {
			stmt = con.createStatement();
			sqlStatement = "DROP TABLE " + tableName;
			//System.out.println("Executing: " + sqlStatement);
			stmt.executeUpdate(sqlStatement);
		} catch (SQLException e) {
			System.out.println("Error dropping table: " + e);
		}

		// Remove the schema from the database
		try {
			stmt = con.createStatement();
			sqlStatement = "DROP SCHEMA " + schemaName + " RESTRICT";
			//System.out.println("Executing: " + sqlStatement);
			stmt.executeUpdate(sqlStatement);
		} catch (SQLException e) {
			System.out.println("Error Dropping schema: " + e);
		}

		try {
			stmt = con.createStatement();
			// Create the CREATE SCHEMA SQL statement and execute it
			sqlStatement = "CREATE SCHEMA " + schemaName;
			//System.out.println("Executing: " + sqlStatement);
			stmt.executeUpdate(sqlStatement);
		} catch (SQLException e) {
			System.out.println("Error creating schema: " + e);
		}

		// create a table
		try {
			stmt = con.createStatement();
			// Create the CREATE TABLE SQL statement and execute it
			sqlStatement = "CREATE TABLE " + tableName
					+ " (NAME VARCHAR(20))";
			//System.out.println("Executing: " + sqlStatement);
			stmt.executeUpdate(sqlStatement);
		} catch (SQLException e) {
			System.out.println("Error creating table: " + e);
		}

		// Execute some SQL statements on the table: Insert, Select and Delete
		try {
			stmt = con.createStatement();
			sqlStatement = "INSERT INTO " + tableName
					+ " VALUES (\'John Smith\')";
			// System.out.println("Executing: " + sqlStatement);
			stmt.executeUpdate(sqlStatement);

			sqlStatement = "SELECT * FROM " + tableName + " FETCH FIRST 1 ROWS ONLY";
			ResultSet rs = stmt.executeQuery(sqlStatement);
			// System.out.println("Executing: " + sqlStatement);

			// Process the result set
			String attN = "null";
			while (rs.next()) {
				attN = rs.getString(1);
				System.out.println("Add Attendee: " + attN + " successfully.");
			}
			request.setAttribute("attName", attN);
			// Close the ResultSet
			rs.close();

		} catch (SQLException e) {
			System.out.println("Error executing:" + sqlStatement);
			System.out.println("SQL Exception: " + e);
		}

		// Close everything off
		try {
			// Close the Statement
			stmt.close();
			// Connection must be on a unit-of-work boundary to allow close
			con.commit();
			// Close the connection
			con.close();
			// System.out.println("Finished");

		} catch (SQLException e) {
			System.out.println("Error closing things off");
			System.out.println("SQL Exception: " + e);
		}

		String path="/welcome.jsp";
		dispatch(request,response,path);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void dispatch(HttpServletRequest request,
			HttpServletResponse response, String page)
			throws javax.servlet.ServletException, java.io.IOException {
		RequestDispatcher dispatcher = getServletContext()
				.getRequestDispatcher(page);
		dispatcher.forward(request, response);
	}
}
